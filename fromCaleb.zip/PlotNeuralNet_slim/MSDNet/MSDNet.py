import sys
sys.path.append('../')
from pycore.tikzeng import *
from pycore.blocks import *

# defined your arch
arch = [
    to_head( '..' ),
    to_cor(),
    to_begin(),

    # Input of network
    misc_input('input', width=2, height=40, depth=40),

    # ====== FIRST LAYER =======
    to_Conv("full_0", s_filer="I", n_filer='1', offset="(5, 0, 0)", to="(input-east)", width=2, height=40, depth=40),
    to_Conv("half_0", s_filer="d(I)", n_filer='2', offset="(-0.5, -5, 0)", to="(full_0-south)", width=4, height=20, depth=20),
    to_Conv("quart_0", s_filer="d(d(I))", n_filer='4', offset="(-0.75, -3.5, 0)", to="(half_0-south)", width=8, height=10, depth=10),
    to_connection("input", "full_0"),
    to_connection_vert("full_0", "half_0"),
    to_connection_vert("half_0", "quart_0"),

    # ====== SECOND LAYER =======
    # Regular Convs
    to_Copy("full_1_cat", s_filer="I", n_filer='1', offset="(7, 0, 0)", to="(full_0-east)", width=2, height=40,
            depth=40),
    to_Conv("full_1_conv", s_filer="I", n_filer='1', offset="(0, 0, 0)", to="(full_1_cat-east)", width=2, height=40,
            depth=40),

    to_connection("full_0", "full_1_cat"),
    to_skip_full("full_0", "full_1_cat"),

    to_Copy("half_1_cat", s_filer="d(I)", n_filer='2', offset="(-1, -5, 0)", to="(full_1_cat-south)", width=4,
            height=20,
            depth=20),
    to_Conv("half_1_conv", s_filer="d(I)", n_filer='2', offset="(0, 0, 0)", to="(half_1_cat-east)", width=4, height=20,
            depth=20),
    to_connection("half_0", "half_1_cat"),
    to_skip_full("half_0", "half_1_cat"),
    to_connection("full_0", "half_1_cat"),

    to_Copy("quart_1_cat", s_filer="d(d(I))", n_filer='4', offset="(-1, -3.5, 0)", to="(half_1_cat-south)", width=8,
            height=10,
            depth=10),
    to_Conv("quart_1_conv", s_filer="d(d(I))", n_filer='4', offset="(0, 0, 0)", to="(quart_1_cat-east)", width=8,
            height=10,
            depth=10),
    to_connection("quart_0", "quart_1_cat"),
    to_skip_full("quart_0", "quart_1_cat", pos=1.4),
    to_connection("half_0", "quart_1_cat"),

    # ====== THIRD LAYER =======
    # Regular Convs
    to_Copy("full_2_cat", s_filer="I", n_filer='1', offset="(7, 0, 0)", to="(full_1_conv-east)", width=2, height=40, depth=40),
    to_Conv("full_2_conv", s_filer="I", n_filer='1', offset="(0, 0, 0)", to="(full_2_cat-east)", width=2, height=40, depth=40),
    to_connection("full_1_conv", "full_2_cat"),
    to_skip_full("full_1_conv", "full_2_cat"),

    to_Copy("half_2_cat", s_filer="d(I)", n_filer='2', offset="(-1, -5, 0)", to="(full_2_cat-southeast)", width=4,
            height=20,
            depth=20),
    to_Conv("half_2_conv", s_filer="d(I)", n_filer='2', offset="(0, 0, 0)", to="(half_2_cat-east)", width=4, height=20,
            depth=20),
    to_connection("half_1_conv", "half_2_cat"),
    to_skip_full("half_1_conv", "half_2_cat"),
    to_connection("full_1_conv", "half_2_cat"),

    to_Copy("quart_2_cat", s_filer="d(d(I))", n_filer='4', offset="(-1, -3.5, 0)", to="(half_2_cat-south)", width=8,
            height=10,
            depth=10),
    to_Conv("quart_2_conv", s_filer="d(d(I))", n_filer='4', offset="(0, 0, 0)", to="(quart_2_cat-east)", width=8,
            height=10,
            depth=10),
    to_connection("quart_1_conv", "quart_2_cat"),
    to_skip_full("quart_1_conv", "quart_2_cat", pos=1.4),
    to_connection("half_1_conv", "quart_2_cat"),

    # ====== FOURTH LAYER =======
    # Regular Convs
    to_Copy("full_3_cat", s_filer="I", n_filer='1', offset="(7, 0, 0)", to="(full_2_conv-east)", width=2, height=40,
            depth=40),
    to_Conv("full_3_conv", s_filer="I", n_filer='1', offset="(0, 0, 0)", to="(full_3_cat-east)", width=2, height=40,
            depth=40),
    to_connection("full_2_conv", "full_3_cat"),
    to_skip_full("full_2_conv", "full_3_cat"),

    to_Copy("half_3_cat", s_filer="d(I)", n_filer='2', offset="(-1, -5, 0)", to="(full_3_cat-southeast)", width=4,
            height=20,
            depth=20),
    to_Conv("half_3_conv", s_filer="d(I)", n_filer='2', offset="(0, 0, 0)", to="(half_3_cat-east)", width=4, height=20,
            depth=20),
    to_connection("half_2_conv", "half_3_cat"),
    to_skip_full("half_2_conv", "half_3_cat"),
    to_connection("full_2_conv", "half_3_cat"),

    to_Copy("quart_3_cat", s_filer="d(d(I))", n_filer='4', offset="(-1, -3.5, 0)", to="(half_3_cat-south)", width=8,
            height=10,
            depth=10),
    to_Conv("quart_3_conv", s_filer="d(d(I))", n_filer='4', offset="(0, 0, 0)", to="(quart_3_cat-east)", width=8,
            height=10,
            depth=10),
    to_connection_and_classification("quart_2_conv", "quart_3_cat"),
    to_skip_full("quart_2_conv", "quart_3_cat", pos=1.4),
    to_connection("half_2_conv", "quart_3_cat"),

    to_end()
    ]

def main():
    namefile = str(sys.argv[0]).split('.')[0]
    to_generate(arch, namefile + '.tex' )

if __name__ == '__main__':
    main()
